#pragma once

class CPictureWindow
{
public:
	CPictureWindow(void);
	~CPictureWindow(void);
};
