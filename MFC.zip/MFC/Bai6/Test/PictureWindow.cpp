#include "StdAfx.h"
#include "PictureWindow.h"

CPictureWindow::CPictureWindow(void)
{
}

CPictureWindow::~CPictureWindow(void)
{
}
